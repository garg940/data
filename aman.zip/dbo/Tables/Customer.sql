CREATE TABLE [dbo].[Customer] (

	[CustomerId] bigint NULL, 
	[Age] bigint NULL, 
	[City] varchar(8000) NULL, 
	[State] varchar(8000) NULL, 
	[Name] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[Customer] ADD CONSTRAINT UQ_f24669a4_7a2f_4dcd_acff_c24276bfb71d unique NONCLUSTERED ([CustomerId]);
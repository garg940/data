CREATE TABLE [dbo].[Sales] (

	[OrderNo] bigint NULL, 
	[ItemID] bigint NULL, 
	[SalesDate] date NULL, 
	[DeilveryDate] date NULL, 
	[CustomerId] bigint NULL, 
	[CityId] bigint NULL, 
	[Qty] bigint NULL, 
	[Price] bigint NULL, 
	[cost] bigint NULL, 
	[DiscountPercent] bigint NULL
);


GO
ALTER TABLE [dbo].[Sales] ADD CONSTRAINT FK_29902f00_674a_4f5b_a56b_48b296939f6b FOREIGN KEY ([CustomerId]) REFERENCES dbo.Customer([CustomerId]);
GO
ALTER TABLE [dbo].[Sales] ADD CONSTRAINT FK_53cd0267_a25a_4feb_bd32_34d53ae5570a FOREIGN KEY ([CityId]) REFERENCES dbo.Geography([CityId]);
GO
ALTER TABLE [dbo].[Sales] ADD CONSTRAINT FK_a7ea8e66_832a_429e_a65c_88b3caee9ab9 FOREIGN KEY ([ItemID]) REFERENCES dbo.Item([ItemId]);
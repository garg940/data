CREATE TABLE [dbo].[Geography] (

	[CityId] bigint NULL, 
	[City] varchar(8000) NULL, 
	[State] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[Geography] ADD CONSTRAINT UQ_489876b2_56a3_45df_92fc_9c32b5094501 unique NONCLUSTERED ([CityId]);
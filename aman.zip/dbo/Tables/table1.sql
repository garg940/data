CREATE TABLE [dbo].[table1] (

	[col1] int NOT NULL
);


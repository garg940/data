CREATE TABLE [dbo].[Item] (

	[ItemId] bigint NULL, 
	[Name] varchar(8000) NULL, 
	[BrandId] bigint NULL, 
	[CategoryId] bigint NULL, 
	[SubCategoryId] bigint NULL, 
	[Brand] varchar(8000) NULL, 
	[Category] varchar(8000) NULL, 
	[SubCategory] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[Item] ADD CONSTRAINT UQ_21df50b7_ff63_463a_ae14_d3001dc6b2db unique NONCLUSTERED ([ItemId]);